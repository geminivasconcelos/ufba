package dominio;

public class Inquilino extends Cliente{

    public Inquilino(String nome, String cpf) {
        super(nome, cpf);
    }
}
